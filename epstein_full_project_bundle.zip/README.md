# Epstein Files — Provenance-Safe Document Analysis Pipeline

A reproducible, audit-friendly pipeline for large PDF releases:

**Download → OCR → Text → Chunk → NER → Postgres (truth) → Qdrant (semantic search)**

- Filesystem stores PDFs, OCR’d PDFs, extracted text, chunk JSONL, entity JSONL.
- PostgreSQL stores structured provenance + relationships (no PDF blobs).
- Qdrant stores embeddings for semantic search over chunks.

## Quickstart (cross-platform, Docker-first)

### Prereqs
- Docker Desktop (Windows/macOS) or Docker Engine (Linux)
- Docker Compose v2

### Run
```bash
make doctor
make bootstrap
make pipeline-init
# edit config.json with seed_urls + allow_domains
make pipeline-run
make db-load
make embed
make search Q="your query"
```

> Windows without `make`: run `scripts/bootstrap.ps1`.
