# Database

PostgreSQL is the primary store for:
- ingestion run tracking
- document metadata and provenance
- hashes for deduplication
- extracted text (including OCR output)

Raw binaries (PDFs, etc.) are stored on disk/object storage and referenced by path/key.

## Quickstart (Local)

1. Start Postgres:
   - `cp .env.example .env`
   - `make up`
2. Apply schema (simple mode):
   - `psql ... -f db/schema.sql`

## Migration Strategy

We ship:
- `db/schema.sql` as a bootstrap schema
- `db/alembic/` for incremental migrations (recommended once code stabilizes)

Start with schema.sql and later transition to Alembic.
