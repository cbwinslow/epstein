# Alembic Migrations

This is a minimal Alembic scaffold.

Bootstrap DB with:
- `db/schema.sql`

Later:
- add manual revisions under `db/alembic/versions/`
- optionally introduce SQLAlchemy models for autogeneration
