# Ops

## Local Postgres (Docker)

1. Copy env:
   - `cp .env.example .env`
2. Edit `.env` (set OPENDISCOURSE_DB_PASSWORD at minimum)
3. Start:
   - `docker compose -f ops/docker-compose.yml up -d`
4. Verify:
   - `docker ps`
   - `docker logs opendiscourse_postgres`

## Next Steps
- Add backup job (pg_dump + rotation)
- Add read-only role for analysis
- Add TLS if DB becomes remote
