# Ingestion (Code)

Primary code lives under:

- `src/opendiscourse/ingestion/`

CLI:

- `cp .env.example .env`
- `make venv && make install-dev`
- `make up`
- apply schema: `psql ... -f db/schema.sql`
- `opendiscourse-ingest --dry-run`
- `opendiscourse-ingest`

Next steps:
- Implement GovInfo bulk download and resume checkpoints
- Add upsert logic for documents and extracted text
