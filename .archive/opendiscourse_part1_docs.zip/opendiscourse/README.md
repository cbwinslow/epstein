# OpenDiscourse

OpenDisourse is an open-source data ingestion, normalization, and analysis platform focused on public governance data.

The system ingests legislative, regulatory, and governmental documents from multiple authoritative sources (e.g. govinfo.gov, congress.gov, openstates.org), normalizes them into a canonical data model, and stores them for downstream analysis, search, and AI-assisted research.

## Goals

- Reliable, resumable ingestion of large public datasets
- Strong data provenance and auditability
- Canonical schema across heterogeneous sources
- Scalable storage for documents + metadata
- AI-ready (RAG, embeddings, summarization, analysis)
- Designed for transparency, not speed hacks

## Non-Goals (for now)

- Real-time streaming ingestion
- Opinionated political analysis
- Closed or proprietary data sources

## High-Level Architecture

- Ingestion workers pull data from public APIs and bulk datasets
- Metadata and structured data are stored in PostgreSQL
- Raw documents are stored on the filesystem or object storage
- OCR and parsing pipelines extract searchable text
- Analysis layers (agents, RAG, dashboards) operate downstream

See `ARCHITECTURE.md` for details.

## Repository Structure

```
.
├── docs/               # System documentation
├── agents/             # Agent definitions and tooling
├── ingestion/          # Ingestion logic (code)
├── db/                 # SQL, migrations, schema
├── ops/                # Deployment & operations
├── README.md
├── PROJECT_SUMMARY.md
├── ARCHITECTURE.md
├── TASKS.md
├── DECISIONS.md
```

## Status

🚧 Active development — ingestion-first phase.

See `PROJECT_SUMMARY.md` and `ROADMAP.md`.

## License

See `LICENSE`.
