# Usage

## Docker-first
```bash
make bootstrap
make pipeline-init
# edit config.json
make pipeline-run
make db-load
make embed
make search Q="your query"
```

## Without make
- Windows: `powershell -ExecutionPolicy Bypass -File .\scripts\bootstrap.ps1`
- macOS/Linux: `./scripts/bootstrap.sh`
