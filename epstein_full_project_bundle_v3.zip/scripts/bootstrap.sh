#!/usr/bin/env bash
set -Eeuo pipefail
COMPOSE="${COMPOSE:-docker compose}"
COMPOSE_FILE="${COMPOSE_FILE:-compose.yml}"
python3 scripts/doctor.py || true
chmod +x ./vector_db_bootstrap.sh
./vector_db_bootstrap.sh --dir ./vector-stack up
${COMPOSE} -f ${COMPOSE_FILE} up -d qdrant postgres
${COMPOSE} -f ${COMPOSE_FILE} --profile pipeline run --rm pipeline epstein_files_pipeline.py init-config --out ./config.json
echo "Edit ./config.json then run: make pipeline-run"
