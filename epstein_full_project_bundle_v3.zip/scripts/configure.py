#!/usr/bin/env python3
# ==============================================================================
# Script Name: scripts/configure.py
# Date: 2025-12-23
# Author: ChatGPT (for Blaine Winslow / cbwinslow)
# Summary:
#   Interactive + non-interactive configuration wizard.
#
#   - Validates Postgres DSN connectivity (optional)
#   - Validates Qdrant health endpoint (optional)
#   - Writes:
#       - .env (optional) with EPSTEIN_DSN / QDRANT_URL
#       - config.json for pipeline run (seed_urls, allow_domains, output_dir, knobs)
#
# Usage:
#   python scripts/configure.py --out-config config.json --write-env .env
#
# Notes:
#   This script is safe to run repeatedly. It will not delete any files.
# ==============================================================================
from __future__ import annotations

import argparse
import json
import os
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import psycopg
from psycopg.rows import dict_row
import urllib.request


DEFAULT_DSN = os.getenv("EPSTEIN_DSN", "postgresql://analysis:analysis@localhost:5432/analysis")
DEFAULT_QDRANT = os.getenv("QDRANT_URL", "http://localhost:6333")


def eprint(msg: str) -> None:
    print(msg, file=sys.stderr)


def http_json(url: str, timeout: int = 5) -> Tuple[bool, Dict[str, Any]]:
    try:
        with urllib.request.urlopen(url, timeout=timeout) as r:
            data = r.read().decode("utf-8", errors="replace")
        return True, json.loads(data)
    except Exception:
        return False, {}


def validate_qdrant(base_url: str) -> Tuple[bool, str]:
    ok, _ = http_json(base_url.rstrip("/") + "/")
    return (ok, "OK" if ok else "Unable to reach Qdrant root endpoint")


def validate_postgres(dsn: str) -> Tuple[bool, str]:
    try:
        with psycopg.connect(dsn, connect_timeout=5) as conn:
            with conn.cursor(row_factory=dict_row) as cur:
                cur.execute("SELECT 1 AS ok;")
                row = cur.fetchone()
                if row and row["ok"] == 1:
                    return True, "OK"
        return False, "Unknown Postgres connectivity issue"
    except Exception as ex:  # noqa: BLE001
        return False, f"{type(ex).__name__}: {ex}"


def parse_csv(s: str) -> List[str]:
    return [x.strip() for x in s.split(",") if x.strip()]


def write_env(path: Path, dsn: str, qdrant: str) -> None:
    lines = []
    lines.append(f"EPSTEIN_DSN={dsn}")
    lines.append(f"QDRANT_URL={qdrant}")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--dsn", default=DEFAULT_DSN, help="Postgres DSN (optional).")
    ap.add_argument("--qdrant-url", default=DEFAULT_QDRANT, help="Qdrant base URL (optional).")
    ap.add_argument("--seed-urls", default="", help="Comma-separated seed URLs for PDFs/pages.")
    ap.add_argument("--allow-domains", default="", help="Comma-separated allowlist of domains.")
    ap.add_argument("--output-dir", default="./epstein_artifacts", help="Artifacts output directory.")
    ap.add_argument("--chunk-chars", type=int, default=1800)
    ap.add_argument("--chunk-overlap", type=int, default=250)
    ap.add_argument("--spacy-model", default="en_core_web_sm")
    ap.add_argument("--do-ocr", action="store_true", default=True)
    ap.add_argument("--no-ocr", action="store_true", default=False)
    ap.add_argument("--redact-pii", action="store_true", default=True)
    ap.add_argument("--no-redact-pii", action="store_true", default=False)
    ap.add_argument("--out-config", default="config.json")
    ap.add_argument("--write-env", default="", help="Write a .env file at this path (optional).")
    ap.add_argument("--skip-checks", action="store_true", help="Skip DSN/Qdrant connectivity checks.")
    args = ap.parse_args()

    do_ocr = args.do_ocr and not args.no_ocr
    redact = args.redact_pii and not args.no_redact_pii

    seed_urls = parse_csv(args.seed_urls) if args.seed_urls else []
    allow_domains = parse_csv(args.allow_domains) if args.allow_domains else []

    if not args.skip_checks:
        okp, msgp = validate_postgres(args.dsn)
        if okp:
            print(f"✅ Postgres: {msgp}")
        else:
            eprint(f"⚠️ Postgres check failed: {msgp}")

        okq, msgq = validate_qdrant(args.qdrant_url)
        if okq:
            print(f"✅ Qdrant: {msgq}")
        else:
            eprint(f"⚠️ Qdrant check failed: {msgq}")

    cfg = {
        "seed_urls": seed_urls,
        "allow_domains": allow_domains,
        "output_dir": args.output_dir,
        "do_ocr": bool(do_ocr),
        "redact_pii": bool(redact),
        "chunk_chars": int(args.chunk_chars),
        "chunk_overlap": int(args.chunk_overlap),
        "spacy_model": str(args.spacy_model),
    }

    out_path = Path(args.out_config)
    out_path.write_text(json.dumps(cfg, indent=2) + "\n", encoding="utf-8")
    print(f"✅ Wrote config: {out_path}")

    if args.write_env:
        env_path = Path(args.write_env)
        write_env(env_path, args.dsn, args.qdrant_url)
        print(f"✅ Wrote env: {env_path}")

    if not seed_urls:
        eprint("ℹ️ seed_urls is empty. Edit config.json or re-run configure with --seed-urls ...")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
