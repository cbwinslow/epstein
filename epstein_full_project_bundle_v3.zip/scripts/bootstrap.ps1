$ErrorActionPreference = "Stop"
function Info($m){ Write-Host "[bootstrap] $m" }
$compose = if ($env:COMPOSE) { $env:COMPOSE } else { "docker compose" }
$composeFile = if ($env:COMPOSE_FILE) { $env:COMPOSE_FILE } else { "compose.yml" }
Info "doctor"; python scripts/doctor.py | Out-Host
Info "schema+stack"; bash -lc "chmod +x ./vector_db_bootstrap.sh && ./vector_db_bootstrap.sh --dir ./vector-stack up" | Out-Host
Invoke-Expression "$compose -f $composeFile up -d qdrant postgres" | Out-Host
Info "init config"; Invoke-Expression "$compose -f $composeFile --profile pipeline run --rm pipeline epstein_files_pipeline.py init-config --out ./config.json" | Out-Host
Info "done"; Write-Host "Edit .\config.json then run make pipeline-run (or docker compose equivalents)."
