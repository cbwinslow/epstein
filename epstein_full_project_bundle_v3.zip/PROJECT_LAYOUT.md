# Project Layout

```
.
├── epstein_files_pipeline.py
├── db_ingest_artifacts.py
├── qdrant_embed_chunks.py
├── qdrant_semantic_search.py
├── vector_db_bootstrap.sh
├── compose.yml
├── Dockerfile
├── pyproject.toml
├── Makefile
├── .env.example
├── scripts/
│   ├── doctor.py
│   ├── bootstrap.sh
│   └── bootstrap.ps1
└── rulebook_packs/
    └── epstein-pipeline-pack/
```
