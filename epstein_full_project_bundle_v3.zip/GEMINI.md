# GEMINI.md

This is a short context file for Gemini/Cursor-style assistants.

- Repo: Epstein provenance-safe document pipeline
- Workflow: `make bootstrap` → `make pipeline-run` → `make db-load` → `make embed` → `make search`
- Evidence: never assert facts without doc_id + chunk offsets + source_url.
