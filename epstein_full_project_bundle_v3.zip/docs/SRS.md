# SRS — Epstein Files Document Analysis Pipeline

## 1. Purpose
Provide a reproducible, provenance-safe pipeline to ingest large PDF releases, extract structured signals, and enable semantic search.

## 2. Goals
- Reproducible runs with immutable provenance (doc_id = SHA256 of raw PDF bytes).
- Non-destructive, idempotent processing.
- Storage split:
  - Filesystem for artifacts
  - Postgres for structured truth
  - Qdrant for embeddings/search

## 3. Non-Goals
- Publishing or asserting factual claims without evidence trails.
- Storing PDFs as SQL blobs.

## 4. Users
- Analysts, researchers, auditors.
- AI agents assisting with triage and extraction.

## 5. Functional Requirements
FR1: Download and catalog PDFs from allow-listed domains.
FR2: OCR PDFs when text layer missing.
FR3: Extract text and redact basic PII for safe exports.
FR4: Chunk text with deterministic offsets and overlap.
FR5: NER extraction with offsets and labels.
FR6: Ingest into Postgres (documents, chunks, entities, runs, failures).
FR7: Embed chunks and upsert to Qdrant (idempotent by chunk_id).
FR8: Provide CLI search for semantic retrieval with provenance payload.

## 6. Non-Functional Requirements
- Auditability: every output references doc_id + offsets + source_url.
- Portability: Docker-first; optional existing infra.
- Security: localhost-bound services by default; no secrets in repo.
- Reliability: logs + failures captured; safe retries.

## 7. Interfaces
- Make targets and scripts under `scripts/`.
- Config: `config.json` + optional `.env`.

## 8. Acceptance Criteria
- After demo run: non-zero counts in Postgres tables and Qdrant collection exists.
