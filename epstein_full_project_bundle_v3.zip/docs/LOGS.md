# Logs

## Where logs live
- Pipeline run logs are written under `epstein_artifacts/` (runs + failures).
- Docker logs can be read via `docker compose logs`.

## What to capture
- Start/end time
- Version (git SHA)
- Config used
- Counts ingested
- Failures with stack traces
