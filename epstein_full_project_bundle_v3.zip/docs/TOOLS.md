# Tools

## Core scripts
- `epstein_files_pipeline.py`: produces artifacts
- `db_ingest_artifacts.py`: loads artifacts into Postgres
- `qdrant_embed_chunks.py`: embeds chunks → Qdrant
- `qdrant_semantic_search.py`: semantic search CLI
- `scripts/configure.py`: validates endpoints + writes config/env
- `scripts/doctor.py`: environment checks

## External dependencies (Docker image)
- ocrmypdf, tesseract, ghostscript, poppler-utils
