# Features

## Pipeline
- Download discovery
- OCR via ocrmypdf
- Text extraction
- Chunking with overlap
- spaCy NER
- Artifact manifests and run logs

## Storage
- Postgres schema `doc_analysis.*`
- Qdrant collection for vectors

## Developer Experience
- Docker-first
- Cross-platform bootstrap
- GitHub Actions CI (lint + demo smoke)
- Rulebook-AI pack for agent context
