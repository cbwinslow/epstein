# Project Summary

This repository implements the Epstein Files provenance-safe document analysis pipeline.

## Key design decisions
- PDFs and derived artifacts live on the filesystem under `epstein_artifacts/`.
- Postgres stores structured provenance and relationships (no PDF blobs).
- Qdrant stores embeddings for semantic search over chunk text.

## Primary entrypoints
- `Makefile` (recommended)
- `scripts/bootstrap.sh` and `scripts/bootstrap.ps1` (no make)
- `scripts/configure.py` (existing infra configuration)
- `make demo` (offline smoke test)
