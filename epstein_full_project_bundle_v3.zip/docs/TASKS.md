# Tasks

- [x] Docker-first reproducible stack (Postgres+pgvector + Qdrant)
- [x] Provenance-safe pipeline + ingest
- [x] Embeddings + semantic search CLI
- [x] CI workflow (lint + offline demo smoke)
- [ ] Hybrid retrieval (Postgres filters + Qdrant vectors)
- [ ] Entity normalization / alias resolution
- [ ] Safe publisher (Astro / Cloudflare Pages)
