# TODO

## Near-term
- Add `scripts/configure.py` enhancements: schema introspection, version pinning.
- Add `make doctor` checks for port conflicts.
- Add optional `--no-network` mode for pipeline discovery.

## Medium-term
- Add pgvector option for hybrid search without Qdrant.
- Add “safe exports” site generator.

## Long-term
- Multi-node download/orchestration (homelab cluster).
- Distributed embedding jobs.
