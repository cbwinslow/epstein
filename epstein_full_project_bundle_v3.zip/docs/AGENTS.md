# Agents

This repo is designed to be AI-agent friendly.

## Recommended agent roles
- **Ingestion Agent**: monitors seed sources, updates config seeds.
- **OCR/Extraction Agent**: validates OCR quality, flags failures.
- **DB Curator Agent**: checks schema, dedupe, validates counts.
- **Search/Triage Agent**: runs semantic search and produces *evidence-linked* summaries.
- **Safety Agent**: enforces redaction and safe export policies.

## Hard rules for agents
- Never claim a fact without linking: doc_id + chunk_id + offsets + source_url.
- Prefer creating tasks/issues over silent changes.
