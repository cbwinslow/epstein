# Rules

## Operational
- Auditability over speed
- Idempotent reruns
- No destructive actions without explicit flag
- Localhost binding by default

## Evidence requirements
Every finding must include:
- doc_id
- chunk_id
- start_char/end_char
- source_url
- excerpt text
