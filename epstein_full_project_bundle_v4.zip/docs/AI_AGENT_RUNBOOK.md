# AI Agent Runbook — Epstein Pipeline

This is the operating manual for AI agents (and humans) working in this repo.

## Core principle
**Auditability > speed.** Every statement must be traceable to source evidence.

## Evidence citation format (required)
When an agent writes any “finding”, it MUST include the following fields:

- `doc_id`: SHA256 of raw PDF bytes (the canonical document key)
- `chunk_id`: integer id in `doc_analysis.chunks` and Qdrant point id
- `offsets`: `start_char..end_char` within the extracted text
- `source_url`: original URL captured in `doc_analysis.documents`
- `excerpt`: short excerpt from the chunk (<= 600 chars preferred)
- `confidence`: 0.0–1.0 (agent’s internal confidence, not a “truth score”)

**Template**

```yaml
finding:
  summary: "<one-sentence, cautious summary>"
  doc_id: "<sha256>"
  chunk_id: <int>
  offsets: "<start>..<end>"
  source_url: "<url>"
  excerpt: "<short excerpt>"
  confidence: 0.00
```

## Allowed outputs by default
- Summaries of retrieved excerpts
- Entity lists and co-occurrence hints
- “Needs review” notes

## Disallowed outputs by default
- Claims of guilt/innocence
- Personal accusations
- Publishing PII (names can appear in historical docs; still apply safe-export rules)

## Safe export rules
Anything written to `epstein_artifacts/safe_exports/` must:
- avoid raw PII when possible,
- keep evidence fields,
- prefer redacted excerpting (no full pages).

## Operational playbooks

### A) Fresh clone to working pipeline
1. `make doctor`
2. `make bootstrap`
3. `make pipeline-init`
4. edit `config.json` (seed_urls + allow_domains)
5. `make pipeline-run`
6. `make db-load`
7. `make embed`
8. `make search Q="..."`

### B) Existing infrastructure
1. `python scripts/configure.py --dsn <...> --qdrant-url <...> --write-env .env --out-config config.json`
2. Run pipeline + db-load + embed/search normally.

### C) Troubleshooting
- If containers won’t start: `make doctor`, check port warnings.
- If OCR fails: inspect `epstein_artifacts/failures.jsonl` and the corresponding raw/OCR PDFs.
- If search empty: confirm `make db-load` inserted chunks and `make embed` created Qdrant points.
