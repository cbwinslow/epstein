#!/usr/bin/env python3
from __future__ import annotations

import json
import os
import shutil
import socket
import subprocess
import sys
import urllib.request
from typing import Tuple


# ==============================================================================
# Script Name: scripts/doctor.py
# Date: 2025-12-23
# Author: ChatGPT (for Blaine Winslow / cbwinslow)
# Summary:
#   Environment diagnostics for the Epstein pipeline repository.
#
#   Checks:
#     - Docker daemon + docker compose plugin
#     - Qdrant reachability
#     - Port collision checks (Postgres/Qdrant default ports)
#     - Disk space sanity checks
#     - Docker volume presence/health (basic)
#
# Exit codes:
#   0: all good
#   2: warnings (non-fatal)
#   3: failures (fatal for running the stack)
# ==============================================================================


def run(cmd: list[str], timeout: int = 12) -> Tuple[int, str]:
    try:
        p = subprocess.run(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            check=False,
            timeout=timeout,
        )
        return p.returncode, p.stdout.strip()
    except Exception as e:  # noqa: BLE001
        return 99, str(e)


def http_json(url: str, timeout: int = 4) -> Tuple[bool, dict]:
    try:
        with urllib.request.urlopen(url, timeout=timeout) as r:
            data = r.read().decode("utf-8", errors="replace")
        return True, json.loads(data)
    except Exception:
        return False, {}


def can_connect(host: str, port: int, timeout: float = 0.5) -> bool:
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except Exception:
        return False


def disk_ok(path: str = ".", min_free_gb: float = 2.0) -> Tuple[bool, str]:
    usage = shutil.disk_usage(path)
    free_gb = usage.free / (1024**3)
    if free_gb < min_free_gb:
        return False, f"Low free disk: {free_gb:.2f} GB (< {min_free_gb:.2f} GB)"
    return True, f"Free disk: {free_gb:.2f} GB"


def docker_volumes_status() -> Tuple[bool, str]:
    rc, out = run(["docker", "volume", "ls", "--format", "{{.Name}}"])
    if rc != 0:
        return False, "Unable to list docker volumes"
    names = [x.strip() for x in out.splitlines() if x.strip()]
    if not names:
        return True, "No docker volumes found (OK for fresh system)"
    return True, f"Docker volumes reachable (count={len(names)})"


def main() -> int:
    failures: list[str] = []
    warnings: list[str] = []

    rc, _ = run(["docker", "version"])
    if rc != 0:
        failures.append("Docker not available (is the daemon running?)")
    else:
        print("✅ Docker OK")

    rc, _ = run(["docker", "compose", "version"])
    if rc != 0:
        warnings.append("docker compose plugin not found.")
    else:
        print("✅ docker compose OK")

    pg_port = int(os.getenv("POSTGRES_PORT", "5432"))
    qdrant_port = int(os.getenv("QDRANT_PORT", "6333"))
    qdrant_grpc = int(os.getenv("QDRANT_GRPC_PORT", "6334"))

    if can_connect("127.0.0.1", pg_port):
        warnings.append(f"Port {pg_port} is already accepting connections (Postgres collision?)")
    if can_connect("127.0.0.1", qdrant_port):
        warnings.append(f"Port {qdrant_port} is already accepting connections (Qdrant collision?)")
    if can_connect("127.0.0.1", qdrant_grpc):
        warnings.append(f"Port {qdrant_grpc} is already accepting connections (Qdrant gRPC collision?)")

    ok, _ = http_json(f"http://127.0.0.1:{qdrant_port}/")
    if ok:
        print("✅ Qdrant reachable on localhost")
    else:
        warnings.append("Qdrant not reachable on localhost (run `make bootstrap`).")

    okd, msgd = disk_ok(".", min_free_gb=float(os.getenv("MIN_FREE_GB", "2.0")))
    if okd:
        print(f"✅ {msgd}")
    else:
        warnings.append(msgd)

    okv, msgv = docker_volumes_status()
    if okv:
        print(f"✅ {msgv}")
    else:
        warnings.append(msgv)

    if failures:
        print("\n❌ Failures:")
        for f in failures:
            print(f"  - {f}")
        return 3

    if warnings:
        print("\n⚠️ Warnings:")
        for w in warnings:
            print(f"  - {w}")
        return 2

    print("\nAll good.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
